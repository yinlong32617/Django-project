
from django.shortcuts import render
from django.db.models import Count

from .models import Child
from django.http import Http404

def Group28MissKids(request, countries):
    children = Child.objects.filter(countries=countries).order_by("countries")
    return render(request, 'Group28MissKids.html', {'children': children})

def Group28Countries(request):
    countries = Child.objects.values('countries').annotate(dcount=Count('countries')).order_by("countries")
    return render(request,'Group28Countries.html', {'countries': countries})

def Group28details(request,id):
    try:
        child = Child.objects.get(id=id)
    except Child.DoesNotExist:
        raise Http404('Child not found')
    return render(request,'Group28details.html',{'child': child})




