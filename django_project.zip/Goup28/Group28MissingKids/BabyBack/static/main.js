var hiddenClass = 'hidden';
var shownClass = 'toggled-from-hidden';

function childSectionHover() {
    var children = this.children;
    for(var i = 0; i < children.length; i++) {
        var child = children[i];
        if (child.className === hiddenClass) {
            child.className = shownClass;
        }
    }
}

function childSectionEndHover() {
    var children = this.children;
    for(var i = 0; i < children.length; i++) {
        var child = children[i];
        if (child.className === shownClass) {
            child.className = hiddenClass;
        }
    }
}

(function() {
    var childSections = document.getElementsByClassName('childName');
    for(var i = 0; i < childSections.length; i++) {
        childSections[i].addEventListener('mouseover', childSectionHover);
        childSections[i].addEventListener('mouseout', childSectionEndHover);
    }
}());
