from django.apps import AppConfig


class BabybackConfig(AppConfig):
    name = 'BabyBack'
